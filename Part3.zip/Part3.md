```python

```

## EMATM0048 - Software Development: Programming and Algorithms
### Part 3

Prepared by: Rajdeep Sarkar

Jan, 2021



This part of SDPA coursework will focus on Data Analytics on a real world dataset.

### Source

- The dataset for this application has been taken from Alpha Vantage API which collects live data of different series of cryptocurrencies and stocks.
- The source link is as follows: https://www.alphavantage.co/


Importing required libraries


```python
# importing Pandas library
import pandas
# importing matplotlib library for plotting graphs
import matplotlib.pyplot as plt
# importing time series library from Alpha Vantage
from alpha_vantage.timeseries import TimeSeries
# importing pprint for pretty-printing
from pprint import pprint
```

We will analyse the daily data of Microsoft 'MSFT' stocks.


```python
time_series_data = TimeSeries(key='FVFCOFUE2Y0IA3FD', output_format='pandas')
data, metadata = time_series_data.get_daily(symbol='MSFT', outputsize='full')
```

Printing top 10 lines of the dataframe


```python
pprint(data.head(10))

```

                1. open  2. high    3. low  4. close   5. volume
    date                                                        
    2021-01-26   231.86   234.18  230.0800    232.33  49169601.0
    2021-01-25   229.12   229.78  224.2200    229.53  33152095.0
    2021-01-22   227.08   230.07  225.8000    225.95  30172663.0
    2021-01-21   224.70   226.30  222.4200    224.97  30749553.0
    2021-01-20   217.70   225.79  217.2908    224.34  37777260.0
    2021-01-19   213.75   216.98  212.6300    216.44  30480859.0
    2021-01-15   213.52   214.51  212.0300    212.65  31746512.0
    2021-01-14   215.91   217.46  212.7400    213.02  29346737.0
    2021-01-13   214.02   216.76  213.9266    216.34  20087080.0
    2021-01-12   216.50   217.10  213.3202    214.93  23148341.0
    

Loading the dataframe using Pandas


```python
ts_df = pandas.DataFrame(data)

```

Renaming Columns names into desired names


```python
ts_df.columns = ['open', 'high', 'low', 'close', 'volume']

```

### Variables

As the dataset is of Stocks value per day, there are 5 variables of our interest
1. open : The opening stock value on that day
2. high : The highest stock value on that day
3. low : The lowest stock value on that day
4. close : The closing stock value on that day
5. volume : The total volume of stocks' value sold on that day



```python
# To display column names of the dataframe
print(ts_df. columns)

```

    Index(['open', 'high', 'low', 'close', 'volume'], dtype='object')
    

### Steps for data preparation
1. Loading the dataset into a data frame using pandas.
2. Viewing the number of rows and columns of the dataframe.
3. Checking if there is any Null values in the dataframe.


Exporting the dataframe to .csv file


```python
ts_df.to_csv('ts_df_csv.csv')
```

Fetching the number of rows and columns


```python
rows = ts_df.shape[0]
cols = ts_df.shape[1]
```

Displaying number of rows, columns values


```python
print("\nNumber of Rows: " + str(rows))
print("\nNumber of Columns: " + str(cols))
```

    
    Number of Rows: 5343
    
    Number of Columns: 5
    

To check if the dataframe has any null or missing data


```python
print("\nDoes the dataframe has any null or missing values? \n" + str(ts_df.isnull().values.any()))
```

    
    Does the dataframe has any null or missing values? 
    False
    

To calculate mean, standard deviation, count, min, max of each column


```python
print("\nThe statistics of each column is : \n" +  str(ts_df.describe()))
```

    
    The statistics of each column is : 
                  open         high          low        close        volume
    count  5343.000000  5343.000000  5343.000000  5343.000000  5.343000e+03
    mean     55.055836    55.679511    54.433202    55.068347  4.845456e+07
    std      43.267273    43.764180    42.747268    43.285281  2.807411e+07
    min      15.200000    15.620000    14.870000    15.150000  5.850800e+06
    25%      27.080000    27.320000    26.905000    27.115000  2.918338e+07
    50%      35.510000    35.730000    34.910000    35.440000  4.333320e+07
    75%      64.760000    65.495000    64.225000    64.865000  6.027280e+07
    max     231.860000   234.180000   230.080000   232.330000  5.910522e+08
    

Q1: What id the mean of opening and closing stocks value?
Q2: What is the lowest stock value in the entire dataframe?
Q3: What is the highest stock value in the entire dataframe?


A1: The mean of opening and closing stock value are 55.055836 and 55.068347  #
A2: Lowest stock value is 14.870000
A3: Highest stock value is 234.180000




Visualizing each column in histogram


```python
ts_df.hist(column='volume')
ts_df.hist(column=['open', 'close'])
ts_df.hist(column=['low', 'high'])
plt.show()
```


    
![png](output_27_0.png)
    



    
![png](output_27_1.png)
    



    
![png](output_27_2.png)
    


Visualizing the comparison among columns 'open' vs 'close' stocks per day
and 'high' vs 'low' stocks per day.


```python
ts_df.plot(x='open', y='close')
ts_df.plot(x='high', y='low')

```




    <AxesSubplot:xlabel='high'>




    
![png](output_29_1.png)
    



    
![png](output_29_2.png)
    


### Summary
- We have learnt from the analysis that the stock market is very unpredictable.
- The mean of the opening and closing stock values were close enough.
- The more the data available, we can have a better idea on the analysis of data.

- For further improvement, we must work on few more parameters like, the twitter data of the respective companing, that has an impact on the values of the stocks, so that we can analyse how that stock values are affected by company official's posts on the twitter.
